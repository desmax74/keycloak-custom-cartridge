<?php
        
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);
require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
    
$username = request_var('username', '', true);

//echo $username;

$user_id_ary = array();  

// Get the userid from user name
user_get_id_name($user_id_ary, $username);

foreach ($user_id_ary as $user_id)
{
  //echo "User $user_id";

  // Delete the user
  $mode = 'remove';
  user_delete($mode, $user_id);
}
  
?>