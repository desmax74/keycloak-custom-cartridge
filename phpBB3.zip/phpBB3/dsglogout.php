<?php
        
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);
require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
    
$set_time = time() - 31536000;

$user->set_cookie('track', '', $set_time);
$user->set_cookie('u', '', $set_time);
$user->set_cookie('k', '', $set_time);
$user->set_cookie('sid', '', $set_time);

setcookie('phpbb3_e5znm_sid', '');
// We destroy the session here, the user will be logged out nevertheless
$user->session_kill();
$user->session_begin();


?>