<?php
        
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);
require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
    
  
$username = request_var('username', '', true);
$password = request_var('password', '', true);
$email = request_var('email', '', true);

$user_row = array(
    'username'              => $username,
    'user_password'         => phpbb_hash($password),
    'user_email'            => $email,
    'group_id'              => 8, // DSG API Group
    'user_timezone'         => (float) $data['tz'],
    'user_lang'             => 'en',
    'user_type'             => USER_NORMAL,
    'user_regdate'          => time(),
);

// Register user...
$user_id = user_add($user_row);

  
?>