<?php
        
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);
require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
    
    // Start session management
    $user->session_begin();
    $auth->acl($user->data);
    $user->setup();

    if($user->data['is_registered'])
    {
        //User is already logged in
        //echo "Roger is already logged in";
        redirect(append_sid("{$phpbb_root_path}index.$phpEx"));
    }
    else
    {
        $username = request_var('username', '', true);
        $password = request_var('password', '', true);

        $result = $auth->login($username, $password);

        if ($result['status'] == LOGIN_SUCCESS)
        {
            //User was successfully logged into phpBB
            //echo "Logging Roger in";
            redirect(append_sid("{$phpbb_root_path}index.$phpEx"));
        }
        else
        {
           echo "Forum logged in failed";
        }
    }
?>